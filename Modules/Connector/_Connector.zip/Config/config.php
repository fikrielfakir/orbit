<?php

return [
    'name' => 'Connector',
    'module_version' => '3.0',
    'pid' => 9,
];